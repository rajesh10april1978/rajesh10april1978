package com.adp.coins;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoinsApplicationTests {

	@Test
	void contextLoads() {
	}

}
