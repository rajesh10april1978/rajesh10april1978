package com.adp.coins;

import java.util.HashMap;

public class ValidateRequest {
	String message;
	HashMap<Double, Integer> currencyValue;
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public HashMap<Double, Integer> getCurrencyValue() {
		return currencyValue;
	}
	public void setCurrencyValue(HashMap<Double, Integer> currencyValue) {
		this.currencyValue = currencyValue;
	}
	
	

}
