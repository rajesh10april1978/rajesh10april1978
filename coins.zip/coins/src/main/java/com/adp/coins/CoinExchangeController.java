package com.adp.coins;


import java.util.HashMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CoinExchangeController {
	

	private CoinExchangeService coinExchange;
	private ValidateRequest request;
	
	
	@GetMapping(path="/hello-world")
	public String helloWorld() {
		return "hello world Rajesh";
	}

 @GetMapping("/coin-Exchange/quantity/{quantity}")
	public  ValidateRequest coinExchangeValue(@PathVariable String quantity) {
	 coinExchange= new CoinExchangeService();
	 request= new ValidateRequest();
	 HashMap<Double, Integer> values= new HashMap<Double, Integer>();
	 if (quantity == null) {
		 request.setMessage("Invalid Request");
			return request;
		
	    }
	    int length = quantity.length();
	    if (length == 0) {
	    	request.setMessage("Invalid Request");
			return request;
		
	    }
	   
	    for (int i=0; i < length; i++) {
	        char c = quantity.charAt(i);
	        if (c < '0' || c > '9') {
	        	request.setMessage("Invalid Request");
				return request;
			
	        }
	    }
		int X = Integer.parseInt(quantity);
		
		if(X<0 || X>100) {
			request.setMessage("Invalid Request");
			return request;
		}

		// Set of possible denominations
		int arr[] = {1, 5, 10, 25};

		int N = arr.length;
		//coinExchange.countMinCoinsUtil(X, arr, N);
		//System.out.println(respData.getQuantity());
		values=coinExchange.countMinCoinsUtil(X, arr, N);
		if(values!=null) {
			request.setCurrencyValue(values);
			request.setMessage("Valid Request");
		}
		return request;
		
	}
	
	

}
