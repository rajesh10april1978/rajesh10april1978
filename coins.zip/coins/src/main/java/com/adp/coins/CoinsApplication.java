package com.adp.coins;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoinsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoinsApplication.class, args);
	}

}
