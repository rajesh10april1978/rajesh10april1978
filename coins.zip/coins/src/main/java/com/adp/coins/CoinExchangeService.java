package com.adp.coins;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;



public class CoinExchangeService {
	
	
	 HashMap<Double,Integer> h = new HashMap<Double,Integer>();
	 final int MAX = 100000;

	//dp array to memoize the results
	 int []dp = new int[MAX + 1];

	//List to store the result
	 List<Integer> denomination =
	         new LinkedList<Integer>();

	//Function to find the minimum
	//number of coins to make the
	//sum equals to X
	 int countMinCoins(int n,
	                      int C[], int m)
	{
	// Base case
	if (n == 0)
	{
	 dp[0] = 0;
	 return 0;
	}

	// If previously computed
	// subproblem occurred
	if (dp[n] != -1)
	 return dp[n];

	// Initialize result
	int ret = Integer.MAX_VALUE;

	// Try every coin that has smaller
	// value than n
	for (int i = 0; i < m; i++)
	{
	 if (C[i] <= n)
	 {
	   int x = countMinCoins(n - C[i],
	                         C, m);

	   // Check for Integer.MAX_VALUE to avoid
	   // overflow and see if result
	   // can be minimized
	   if (x != Integer.MAX_VALUE)
	     ret = Math.min(ret, 1 + x);
	 }
	}

	// Memoizing value of current state
	dp[n] = ret;
	return ret;
	}

	//Function to find the possible
	//combination of coins to make
	//the sum equal to X
	 void findSolution(int n,
	                      int C[], int m)
	{
	// Base Case
		 
	if (n == 0)
	{
	 // Print Solutions
	 for (int it : denomination)
	 {
		 double key=it/100.00;
		 if(h.containsKey(key)){
	         h.put(key, h.get(key) + 1*100);
	     } else {
	         h.put(key, 1*100);
	     }
	   System.out.print(it + " ");
	 }
	 
	 System.out.println(h);
	// respData.setQuantity(h);
	 return;
	}

	for (int i = 0; i < m; i++)
	{
	 // Try every coin that has
	 // value smaller than n
	 if (n - C[i] >= 0 &&
	     dp[n - C[i]] + 1 ==
	     dp[n])
	 {
	   // Add current denominations
	   denomination.add(C[i]);

	   // Backtrack
	   findSolution(n - C[i], C, m);
	   break;
	 }
	}
	}

	//Function to find the minimum
	//combinations of coins for value X
	public   HashMap<Double,Integer> countMinCoinsUtil(int X,
	                           int C[], int N)
	{
	// Initialize dp with -1
	for (int i = 0; i < dp.length; i++)
	 dp[i] = -1;

	// Min coins
	int isPossible = countMinCoins(X, C, N);

	// If no solution exists
	if (isPossible == Integer.MAX_VALUE)
	{
	 System.out.print("-1");
	}

	// Backtrack to find the solution
	else
	{
	 findSolution(X, C, N);
	}
	
	return h;
	}

	//Driver code
/*	public  void main(String[] args)
	{
	int X = 35;

	// Set of possible denominations
	int arr[] = {1, 5, 10, 25};

	int N = arr.length;

	// Function Call
	countMinCoinsUtil(X, arr, N);
	}*/
	}